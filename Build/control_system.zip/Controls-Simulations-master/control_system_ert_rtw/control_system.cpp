//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: control_system.cpp
//
// Code generated for Simulink model 'control_system'.
//
// Model version                  : 1.1
// Simulink Coder version         : 8.13 (R2017b) 24-Jul-2017
// C/C++ source code generated on : Fri Feb  7 15:08:15 2020
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "control_system.h"

// Model step function
void control_systemModelClass::step()
{
  // local block i/o variables
  real_T rtb_Model_o1;
  real_T rtb_Model_o2;
  real_T rtb_Model_o3;
  real_T rtb_Model1;

  // ModelReference: '<Root>/Model' incorporates:
  //   Inport: '<Root>/cmd '
  //   Inport: '<Root>/time '

  ModelMDLOBJ1.step(control_system_U.cmd, control_system_U.time, &rtb_Model_o1,
                    &rtb_Model_o2, &rtb_Model_o3);

  // ModelReference: '<Root>/Model1' incorporates:
  //   Inport: '<Root>/x'
  //   Inport: '<Root>/x_dot'
  //   Inport: '<Root>/x_dot_dot'

  Model1MDLOBJ2.step(rtb_Model_o1, rtb_Model_o2, rtb_Model_o3,
                     control_system_U.x, control_system_U.x_dot,
                     control_system_U.x_dot_dot, &rtb_Model1);

  // ModelReference: '<Root>/Model2' incorporates:
  //   Outport: '<Root>/signals'

  Model2MDLOBJ3.step(rtb_Model1, &control_system_Y.signals);
}

// Model initialize function
void control_systemModelClass::initialize()
{
  // (no initialization code required)
}

// Constructor
control_systemModelClass::control_systemModelClass()
{
}

// Destructor
control_systemModelClass::~control_systemModelClass()
{
  // Currently there is no destructor body generated.
}

//
// File trailer for generated code.
//
// [EOF]
//
