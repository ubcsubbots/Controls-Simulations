function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "control_system"};
	this.sidHashMap["control_system"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/cmd "] = {sid: "control_system:9"};
	this.sidHashMap["control_system:9"] = {rtwname: "<Root>/cmd "};
	this.rtwnameHashMap["<Root>/time "] = {sid: "control_system:8"};
	this.sidHashMap["control_system:8"] = {rtwname: "<Root>/time "};
	this.rtwnameHashMap["<Root>/x"] = {sid: "control_system:5"};
	this.sidHashMap["control_system:5"] = {rtwname: "<Root>/x"};
	this.rtwnameHashMap["<Root>/x_dot_dot"] = {sid: "control_system:6"};
	this.sidHashMap["control_system:6"] = {rtwname: "<Root>/x_dot_dot"};
	this.rtwnameHashMap["<Root>/x_dot"] = {sid: "control_system:7"};
	this.sidHashMap["control_system:7"] = {rtwname: "<Root>/x_dot"};
	this.rtwnameHashMap["<Root>/Model"] = {sid: "control_system:1"};
	this.sidHashMap["control_system:1"] = {rtwname: "<Root>/Model"};
	this.rtwnameHashMap["<Root>/Model1"] = {sid: "control_system:2"};
	this.sidHashMap["control_system:2"] = {rtwname: "<Root>/Model1"};
	this.rtwnameHashMap["<Root>/Model2"] = {sid: "control_system:3"};
	this.sidHashMap["control_system:3"] = {rtwname: "<Root>/Model2"};
	this.rtwnameHashMap["<Root>/signals"] = {sid: "control_system:4"};
	this.sidHashMap["control_system:4"] = {rtwname: "<Root>/signals"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
