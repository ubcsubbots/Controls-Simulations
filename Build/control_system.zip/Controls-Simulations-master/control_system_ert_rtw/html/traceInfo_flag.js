function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["control_system.cpp:36c66"]=1;
    this.traceFlag["control_system.cpp:37c21"]=1;
    this.traceFlag["control_system.cpp:37c36"]=1;
    this.traceFlag["control_system.cpp:46c50"]=1;
    this.traceFlag["control_system.cpp:51c34"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["control_system.cpp:36"]=1;
    this.lineTraceFlag["control_system.cpp:37"]=1;
    this.lineTraceFlag["control_system.cpp:44"]=1;
    this.lineTraceFlag["control_system.cpp:45"]=1;
    this.lineTraceFlag["control_system.cpp:46"]=1;
    this.lineTraceFlag["control_system.cpp:51"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
